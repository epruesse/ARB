//
// attribs.hpp
// ~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_ATTRIBS_HPP
#define BOOST_HTXML_ATTRIBS_HPP

#include <string>
using namespace std;

#include <boost/multi_index_container.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/sequenced_index.hpp>
using namespace boost::multi_index;

namespace boost {
  namespace htxml {

    /*!
    Attribute Value for a element
    */
    struct attrib_value
    {
      string  _name;      //!<  Name of the attribute
      string  _value;     //!<  Value for the attribute
      bool    _singleton; //!<  If the attribute is a singleton
    };
    
    /*
    Multiviewing index for attributes of a element.
    sequenced index allows for rebuilding the element in the natural order
    ordered_unique index allows for looking up an attribute name
    */
    struct  byAttribName{};
    typedef multi_index_container<
      attrib_value,
      indexed_by<
        sequenced<>,
        ordered_unique< 
          tag<byAttribName>,
          member<attrib_value, string, &attrib_value::_name> 
        >
      >
    > attrib_list_t;

  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_ATTRIBS_HPP
