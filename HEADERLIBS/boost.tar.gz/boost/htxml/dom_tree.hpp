//
// dom_tree.hpp
// ~~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTML_DOM_TREE_HPP
#define BOOST_HTML_DOM_TREE_HPP

#include <boost/multi_index_container.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/mem_fun.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/sequenced_index.hpp>
using namespace boost::multi_index;

#include <boost/htxml/element.hpp>
#include <boost/htxml/elements/singleton.hpp>
#include <boost/htxml/elements/doctype.hpp>
#include <boost/htxml/elements/comment.hpp>
#include <boost/htxml/elements/script.hpp>
#include <boost/htxml/elements/xml.hpp>
#include <boost/multi_index/mem_fun.hpp>

namespace boost {
  namespace htxml {

    /*!
    The dom_tree class holds the root of the document tree
    */
    class dom_tree
    {
    private:
      // Used to find handlers for elements
      struct byElementName{};
      struct byElementId{};

      typedef multi_index_container<
        ptr_element_t,
        indexed_by<
          ordered_non_unique< 
            tag<byElementName>,
            const_mem_fun<element, size_t, &element::hashName> 
          >,
          ordered_non_unique< 
            tag<byElementId>, 
            const_mem_fun<element, size_t, &element::hashId>
          >
        >
      > element_reference_t;

      typedef element_reference_t::index<byElementName>::type::iterator factory_iterator_t;
      
      /// Multi index that handles elements by ID and element name for DOM functions
      typedef multi_index_container<
        ptr_element_t,
        indexed_by<
          ordered_non_unique< 
            tag<byElementName>,
            const_mem_fun<element, size_t, &element::hashName> 
          >,
          ordered_non_unique< 
            tag<byElementId>, 
            const_mem_fun<element, size_t, &element::hashId>
          >
        >
      > dom_reference_t;

      typedef dom_reference_t::index<byElementName>::type::iterator name_iterator_t;
      typedef dom_reference_t::index<byElementId>::type::iterator   id_iterator_t;

      dom_reference_t     elementReferences;
      dom_reference_t elementHandlers;
      hash<string>        _hasher;
    
    public:
      dom_tree(weak_ptr<element> wparent)
      {
        initialize(wparent);
      }
      
      virtual ~dom_tree()
      {
      }

      void initialize(weak_ptr<element> wparent)
      {
        ptr_element_t parent = wparent.lock();

        // odd-ball handlers that aren't really within the <element></element> or <element /> scheme
        addHandler( ptr_element_t(new elements::doctype(parent)) );
        addHandler( ptr_element_t(new elements::comment(parent)) );
        addHandler( ptr_element_t(new elements::xml(parent)) );
        addHandler( ptr_element_t(new elements::script(parent)) );

        // Some elements are singular and do not require a closer.
        addHandler( ptr_element_t(new elements::singleton("area", parent)) );
        addHandler( ptr_element_t(new elements::singleton("base", parent)) );
        addHandler( ptr_element_t(new elements::singleton("basefont", parent)) );
        addHandler( ptr_element_t(new elements::singleton("br", parent)) );
        addHandler( ptr_element_t(new elements::singleton("col", parent)) );
        addHandler( ptr_element_t(new elements::singleton("colgroup", parent)) );
        addHandler( ptr_element_t(new elements::singleton("frame", parent)) );
        addHandler( ptr_element_t(new elements::singleton("hr", parent)) );
        addHandler( ptr_element_t(new elements::singleton("img", parent)) );
        addHandler( ptr_element_t(new elements::singleton("input", parent)) );
        addHandler( ptr_element_t(new elements::singleton("link", parent)) );
        addHandler( ptr_element_t(new elements::singleton("meta", parent)) );
        addHandler( ptr_element_t(new elements::singleton("param", parent)) );      
      }
    
      /*!
      Adds a element handler to the handler tree.
      
      Any derived custom classes should pass through here in order for the 
      parser to recognize the DOM based element.
      
      \param ptr_element A ptr_element_t object that handles a element.
      */
      void addHandler(ptr_element_t ptr_element)
      {
        elementHandlers.insert(ptr_element);
      }
    
      /*!
      Creating of element objects
      
      Looks up the element name from the elementHandlers list and clones a 
      new copy of the element.

      \param elementName  Name of the element to create
      \param parent       Parent of this element
      \returns            ptr_element_t of the cloned element.
      */
      virtual ptr_element_t factory(string& name, ptr_element_t& parent)
      {
        ptr_element_t elementPtr;

        factory_iterator_t iter( elementHandlers.get<byElementName>().find( _hasher(name) ) );

        if( iter != elementHandlers.get<byElementName>().end() )
          elementPtr = (*iter)->clone();
        else
          elementPtr = ptr_element_t( new element(name, parent) );

        // add this factoried object into the node tree
        parent->addChild(elementPtr);

        // make a reference copy for the getElementsByX functions
        elementReferences.insert(elementPtr);

        return elementPtr;
      }
    
      /*!
      Get a list of elements by element name
      
      \param  name  Element name to retrieve
      \returns      List of elements that match the name parameter
      */
      virtual ptr_element_vector_t getElementsByName(const string& name) const
      {
        ptr_element_vector_t  retData;

        pair<name_iterator_t,name_iterator_t> rangeIter = elementReferences.get<byElementName>().equal_range( _hasher(name) );
        for( name_iterator_t iter = rangeIter.first; iter != rangeIter.second; ++iter )
          retData.push_back( (*iter) );

        return retData;
      }

      /*!
      Get a list of elements by element's ID attribute
      
      \param  id    Id Attribute to retrieve
      \returns      List of elements that match the id parameter
      */
      virtual ptr_element_vector_t getElementsById(const string& id) const
      {
        ptr_element_vector_t  retData;

        pair<id_iterator_t,id_iterator_t> rangeIter = elementReferences.get<byElementId>().equal_range( _hasher(id) );
        for( id_iterator_t iter = rangeIter.first; iter != rangeIter.second; ++iter )
          retData.push_back( (*iter) );

        return retData;
      }
    
    };  
  
  } // namespace htxml
} // namespace boost
  

#endif  // BOOST_HTXML_DOM_TREE_HPP

