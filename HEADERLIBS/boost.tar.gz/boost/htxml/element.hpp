//
// element.hpp
// ~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_ELEMENT_HPP
#define BOOST_HTXML_ELEMENT_HPP

#include <boost/cstdint.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/join.hpp>
#include <boost/functional/hash.hpp>
#include <boost/htxml/attribs.hpp>

#include <vector>
#include <string>
#include <sstream>
#include <streambuf>

using namespace std;

namespace boost {
  namespace htxml {

    // forward decl
    class element;

    /// Typedef for a shared_ptr of element.
    typedef shared_ptr<element>   ptr_element_t;

    ptr_element_t blankElement;

    /// Typedef for a vector of shared_ptr<element> elements
    typedef vector<ptr_element_t> ptr_element_vector_t;

    /*!
    A DOM element

    An element object represents a \<element\>\</element\> element for an
    HTML/XML document. For other element types (e.g. comments, doctype or img)
    you must use a specialized class.

    It is assumed that any document read does not conform to properly
    closed elements. For instance: \<p\>\<b\>something\</p\>\</b\>

    When we close the elements, we pop back to the previous element thus closing
    the elements properly.
    */
    class element : public enable_shared_from_this<element>
    {
    protected:
      typedef weak_ptr<element> weak_element_t;

      weak_element_t  _document;  //!< 'Document' for the xhtml tree
      weak_element_t  _parent;    //!<  Parent object

      enum parser_state_t
      {
        st_none = 0,
        st_value,
        st_singleQuote,
        st_doubleQuote,
        st_tagMarker,
        st_tagMarkerOpen,
        st_tagMarkerClose,
      };

      parser_state_t  parser_state;

    private:
      string        _name;      //!< Element name
      attrib_list_t _attr;      //!< List of attributes for this element
      string        _value;     //!< String value without the embedded elements
      size_t        _pvo;       //!< Offset in the parent's value

      // These two values are used for
      size_t        _hashName;  //!< Hash of the element name
      size_t        _hashId;    //!< Hash of the ID attribute
      ptr_element_vector_t  _children;      //!< Children elements

    public:
      /*!
      Default constructor

      Creates a new element.

      \param name    Name of the element. For instance 'a' for an <a> element
      \param parent  Parent element in the DOM tree.
      */
      element(const string& name, ptr_element_t& parent)
      : _parent(parent),
        _name(name)
      {
        init();
      }

      /*!
      Default constructor

      Creates a new element.

      \param name    Name of the element. For instance 'a' for an <a> element
      \param parent  Parent element in the DOM tree.
      */
      element(const char* name, ptr_element_t& parent)
      : _parent(parent),
        _name(name)
      {
        init();
      }

      /*!
      Destructor
      */
      virtual ~element()
      {
      }

      /*!
      Gets the name of the element

      \returns    Element name of the element.
      */
      const string&  name() const  { return _name; }

      /*!
      Gets the hashed value of a element's 'id' attribute.

      \returns    Hash value of the 'id' attribute
      */
      size_t  hashId() const       { return _hashId; }

      /*!
      Gets the hashed value of a element's name

      \returns    Hash value of the name string
      */
      size_t  hashName() const     { return _hashName; }

      /*!
      Sets the value string of a element

      The value of a element is between \<element\> and the \</element\> space.
      Singleton elements do not have a value associated with them.

      \param value   String to set
      */
      void    setValue(const string& value)
      {
        if( !isSingleton() )
          _value = value;
      }

      /*!
      Gets the value string of a element

      The value of a element is between \<element\> and the \</element\> space.
      Singleton elements do not have a value associated with them.

      @returns    Value string of the element
      */
      string& getValue()                    { return _value; }

      /*!
      Value offset in the parent of a element

      \returns    Parent value offset of the element
      */
      size_t  valueOffset() const           { return _pvo; }

      /*!
      Get the root document

      \returns    Element pointer of the document
      */
      virtual ptr_element_t getDocument()
      {
        return _document.lock();
      }

      /*!
      Adds a child element to the element

      \param child   Child element to add
      */
      virtual void addChild(const ptr_element_t& child)
      {
        child.get()->_pvo = _value.size();
        _children.push_back(child);
      }

      /*!
      Finds a child element by name.

      \param  name  Name of the child element to get.
      \returns A valid child element, or a element named *blank.
      */
      virtual const ptr_element_t& findChild(const string& name)
      {
        ptr_element_vector_t::iterator  iter = firstChild();
        for( ; iter != lastChild(); ++iter )
        {
          if( (*iter)->name() == name )
            return (*iter);
        }

        if( !blankElement )
        {
          blankElement = ptr_element_t(new element);
          blankElement->_name = "blank";
        }

        return blankElement;
      }

      /*!
      Gets the first child of the children list.

      \returns    A random-access iterator addressing the first element in the
                  children list.
      */
      virtual ptr_element_vector_t::iterator  firstChild()
      {
        return _children.begin();
      }

      /*!
      Gets the last child of the children list.

      \returns    A random-access iterator addressing the last element in the
                  children list.
      */
      virtual ptr_element_vector_t::iterator  lastChild()
      {
        return _children.end();
      }

      /*!
      Erases children

      \param b  First element to erase
      \param e  Last element to erase
      */
      virtual void erase(ptr_element_vector_t::iterator b, ptr_element_vector_t::iterator e )
      {
        _children.erase(b,e);
      }

      /*!
      Checks for a attribute

      \param name  Name of the attribute to search for
      \returns      True if the attribute exists
      */
      virtual bool hasAttr(const string& name)
      {
        attrib_list_t::index<byAttribName>::type::iterator nameIter;
        nameIter = _attr.get<byAttribName>().find( name );
        return ( nameIter != _attr.get<byAttribName>().end() );
      }

      /*!
      Sets an attribute of the element

      \param attr  Attribute value to set to a element
      */
      virtual void setAttr(const attrib_value& attr)
      {
        attrib_list_t::index<byAttribName>::type::iterator nameIter;
        nameIter = _attr.get<byAttribName>().find( attr._name );
        if( nameIter == _attr.get<byAttribName>().end() )
          _attr.insert(_attr.begin(), attr);
        else
          _attr.get<byAttribName>().replace(nameIter, attr);

        if( attr._name == "id" )
        {
          hash<string>  hString;
          _hashId = hString( attr._value );
        }
      }

      /*!
      Gets an attribute of the element

      \param name  Attribute to retrieve
      \returns      Attribute value of the element
      */
      virtual const attrib_value& getAttr(const string& name)
      {
        attrib_list_t::index<byAttribName>::type::iterator nameIter;
        nameIter = _attr.get<byAttribName>().find( name );
        return *nameIter;
      }

      /*!
      Deletes an attribute from the element

      \param name  Attribute to remove
      */
      virtual void delAttr(const string& name)
      {
        _attr.get<byAttribName>().erase(name);
      }

      /*!
      Checks if a element is a singleton or not

      \returns    True if the element is a stand-alone element.
      */
      virtual bool isSingleton()
      {
        return false;
      }

      /*!
      Clones a element object

      \returns    A cloned copy of this element
      */
      virtual ptr_element_t clone()
      {
        return ptr_element_t(new element(*this));
      }

      /*!
      Reads a element and it's children

      \param strm    istream to read the input from
      */
      virtual void read(istream& strm)
      {
        // a singleton doesn't read anything
        if( isSingleton() )
          return ;

        setState(st_value);
        ptr_element_t fakeThis( shared_from_this() );

        while( !strm.eof() )
        {
          char ch;
          strm.get(ch);
          switch( ch )
          {
          case '<':
            {
              if( !inQuotes() )
              {
                string elementName = readElement(strm);
                if( elementName[0] == '/' )
                {
                  // we have a hanging '>' out there
                  strm.get();
                  return ;
                }

                // Create a new node and attach it to the parent.
                ptr_element_t newElement = getDocument()->factory(elementName, fakeThis);

                newElement->readAttribs(strm);
                newElement->read(strm);
                continue;
              }
            }
            break;
          case '\'':
            if( !inValue() )
              setState(st_singleQuote);
            else if( !inDouble() )
              setState(st_value);
            break;
          case '"':
            if( !inValue() )
              setState(st_doubleQuote);
            else if( !inSingle() )
              setState(st_value);
            break;
          }

          _value += ch;
        }
      }

      /*!
      Writes the children elements to the stream

      \param  strm    Stream to write to
      */
      virtual void write(ostream& strm, bool withTags = true)
      {
        if( name().length() && withTags )
        {
          strm << "<" ;
          createElement(strm);
          strm << ">";
        }

        ptr_element_vector_t::iterator  elementIter;

        size_t  b(0);
        for( elementIter = _children.begin(); elementIter != _children.end(); ++elementIter )
        {
          string value = _value.substr(b, (*elementIter)->_pvo - b);
//          trim(value);
          strm << value;
          b = (*elementIter)->_pvo;

          (*elementIter)->write(strm, withTags);
        }
        string value = _value.substr(b);
//        trim(value);
        strm << value;

        if( name().length() && withTags )
        {
          strm << "</";
          strm << name();
          strm << ">";
        }
      }

      /*!
      Returns the children elements as a string

      \returns  A string with the children elements
      */
      virtual string as_string(bool withTags = true)
      {
        ostringstream strm;
        write(strm, withTags);
        return string(strm.str());
      }

      /*!
      Get a list of elements by element name

      \param name  Element name to retrieve
      \returns      List of elements that match the name parameter
      */
      virtual ptr_element_vector_t getElementsByName(const string& name) const
      {
        if( _document.use_count() )
        {
          ptr_element_t document(_document);
          return document->getElementsByName(name);
        }

        return ptr_element_vector_t();
      }

      /*!
      Get a list of elements by element's ID attribute

      \param  id    Id Attribute to retrieve
      \returns      List of elements that match the id parameter
      */
      virtual ptr_element_vector_t getElementsById(const string& id) const
      {
        if( _document.use_count() )
        {
          ptr_element_t document(_document);
          return document->getElementsById(id);
        }

        return ptr_element_vector_t();
      }

    protected:
      /*!
      Special constructor


      */
      element()
      {
        init();
      }

      /*!
      Creates a new element.

      \param name    Name of the element. For instance 'a' for an <a> element
      */
      element(const char* name)
      : _name(name)
      {
        init();
      }

      void  init()
      {
        _pvo = 0;
        _hashId  = 0;

        if( _parent.use_count() )
        {
          ptr_element_t parent(_parent);
          _document = parent->_document;
        }

        hash<string>  hString;
        _hashName = hString( _name );
        parser_state = st_none;
      }

      /*!
      */
      bool hasParent() const
      {
        if( _parent.use_count() )
        {
          ptr_element_t parent(_parent);
          return (parent.get() != 0);
        }

        return false;
      }


      /*!
      Get the attribute list

      Used by subclassed objects to retrieve the attributes list for special processing.
      \returns    A attrib_list
      */
      const attrib_list_t&  attributes()  { return _attr; }

      /*!
      Sets the document root for the HTML tree

      This is purely a helper function for the document class.
      \param  document  Document root for the tree
      */
      void  setDocument(ptr_element_t& document)
      {
        _document = document;
      }

      /*!
      Creates a opening element

      Writes the element name and the associated attributes. Attributes are
      written using proper quote conventions as per XHTML standards.
      \param strm  Stream to write to
      */
      virtual void createElement(ostream& strm)
      {
        vector<string>  tojoin;
        tojoin.push_back( name() );
        attrib_list_t::reverse_iterator attribIter = _attr.rbegin();
        for( ; attribIter != _attr.rend(); ++attribIter )
        {
          string attrStr;
          if( (*attribIter)._singleton )
            attrStr = (*attribIter)._name;
          else
            attrStr = (*attribIter)._name + "=\"" + (*attribIter)._value + "\"";

          tojoin.push_back( attrStr );
        }

        strm << join(tojoin, " ");
      }

      /*!
      Reads a element from the stream

      \param strm  Stream to read from
      */
      virtual string readElement(istream& strm)
      {
        // quick element!
        char tchar[16];
        int  i = 0;

        while( !strm.eof() )
        {
          char ch;

          /*
          Start reading off the element. Most elements are within 16 bytes.
          Space is the first delimiter, with the exception of a comment field.
          Somone may do the following: <!--This is a comment

          We need to watch the first 3 chars of the element to see if it is a
          comment.
          */
          strm.get(ch);
          if( isspace(ch) ) break;
          tchar[i++] = ch;

          // check to see if we're a comment!
          if( i == 3 )
          {
            if( tchar[0] == '!' && tchar[1] == '-' && tchar[2] == '-' )
              break;
          }

          // Take a peek for the next char
          ch = strm.peek();
          if( ch == '>' || ch == '/' ) break;
        }
        tchar[i]=0;

        return string(tchar);
      }

      /*!
      Reads the attributes of a element

      Reads the attributes for a element until we reach the '>' marker.
      \param strm  Stream to read attributes from
      */
      virtual void readAttribs(istream& strm)
      {
        ostringstream  sstrm;

        while( !strm.eof() )
        {
          char ch;
          strm.get(ch);
          if( ch == '>' )
            break;
          else
            sstrm << ch;
        }

        parseAttribs(sstrm.str());
      }

      /*!
      Parse the attibutes string

      \param attributes  Attribute string to parse
      */
      virtual void parseAttribs( const string& attributes )
      {
        size_t  i(0), b(0);
        bool inQuote(false);
        for( i = 0; i < attributes.length(); ++i )
        {
          if( isspace(attributes[i]) && !inQuote )
          {
            parseAttrib( attributes.substr(b, i - b) );
            b = i + 1;
          }
          if( i != 0 && attributes[i] == '"' && attributes[i-1] != '\\' )
            inQuote = !inQuote;
        }

        if( b < attributes.length() )
          parseAttrib(attributes.substr(b));
      }

      /*!
      Parses a single attribute string

      \param attribute Attribute to parse
      */
      virtual void parseAttrib( const string& attribute )
      {
        attrib_value  attrib;
        size_t  equalPos = attribute.find("=");
        attrib._name = attribute.substr(0, equalPos);
        if( equalPos != string::npos )
        {
          size_t  sPos = attribute.find_first_of('"');
          if( sPos == string::npos )
            sPos = equalPos + 1;
          else
            sPos++;

          size_t  ePos = attribute.find_last_of('"');
          if( ePos != string::npos )
            ePos = ePos - sPos;
          else
            ePos--;

          // if( ePos < 0 ) ePos = 1;
          attrib._value = attribute.substr(sPos, ePos);
          attrib._singleton = false;
        }
        else
          attrib._singleton = true;

        setAttr(attrib);
      }

      /*!
      Creates a element

      Prefered method of element creation when parsing a file.

      \param name    Name of the element to create
      \param parent  Parent element of the new element
      @returns        New element that was created

      */
      virtual ptr_element_t factory(string& name, ptr_element_t& parent)
      {
        if( _document.use_count() )
        {
          ptr_element_t document(_document);
          return document->factory(name, parent);
        }

        return ptr_element_t( new element(name, parent) );
      }


      void  setState(const parser_state_t state) { parser_state = state; }

      inline bool      inValue() const  { return (parser_state == st_value); }
      inline bool      inSingle() const { return (parser_state == st_singleQuote); }
      inline bool      inDouble() const { return (parser_state == st_doubleQuote); }
      inline bool      inQuotes() const { return (inSingle() || inDouble()); }
      inline bool      inOpen() const   { return (parser_state == st_tagMarkerOpen); }
      inline bool      inClose() const  { return (parser_state == st_tagMarkerClose); }
      inline bool      inTag() const    { return (parser_state == st_tagMarker || inOpen() || inClose()); }

    };

  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_ELEMENT_HPP

