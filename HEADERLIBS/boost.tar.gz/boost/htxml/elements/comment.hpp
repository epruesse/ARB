//
// comment.hpp
// ~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_ELEMENTS_COMMENT_HPP
#define BOOST_HTXML_ELEMENTS_COMMENT_HPP

#include <boost/htxml/element.hpp>

using namespace std;

namespace boost {
  namespace htxml {
    namespace elements {

      /*!
      A XHTML Comment element
      
      A comment element is a specialized element that represents comment 
      (\<!-- --\>) in an XHTML document.
      */
      class comment : public element
      {
      private:
        string _comment;  //!<  Comment string

      public:
        /*!
        Default constructor

        Creates a new comment element.
        \param parent  Parent element in the DOM tree.
        */
        comment(ptr_element_t& parent) : element("!--", parent)
        {
        }

        /*
        Creates a new comment element.
        */
        comment() : element("!--")
        {
        }

        /*!
        Checks if a element is a singleton or not

        \returns    Always returns True
        */
        virtual bool isSingleton() { return true; }

        /*!
        Clones a element object
        
        \returns    A cloned copy of this element
        */
        virtual ptr_element_t clone()
        {
          return ptr_element_t(new comment(*this));
        }

        /*!
        Reads a comment element
        
        \param strm    istream to read the input from
        */
        virtual void read(std::istream& strm)
        {
          std::ostringstream  sstrm;

          int dashCount(0);
          while( !strm.eof() )
          {
            char ch;
            strm.get(ch);

            if( ch == '-' )
              dashCount++;
            else if( dashCount && ch != '>' )
              dashCount--;

            if( ch == '>' && dashCount == 2 )
              break;
            else
              sstrm << ch;
          }

          std::string commentLine = sstrm.str();

          commentLine.erase( commentLine.length() - 2);
          setValue(commentLine);
        }

        /*!
        Writes a comment element
        
        \param  strm    Stream to write to
        */
        virtual void write(std::ostream& strm, bool withTags = true)
        {
          if( withTags )
          {
            strm << "<!--";
            strm << getValue();
            strm << "-->";
          }
        }

      protected:
        /*!
        Reads the attributes of a element
        
        Comments don't have attributes. This is just a filler function.
        
        \param strm  Stream to read attributes from
        */
        virtual void readAttribs(istream& /*strm*/)
        {
        }

      };

    } // namespace elements
  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_ELEMENTS_COMMENT_HPP
