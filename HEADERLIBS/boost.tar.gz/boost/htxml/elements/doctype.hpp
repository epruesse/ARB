//
// doctype.hpp
// ~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_ELEMENTS_DOCTYPE_HPP
#define BOOST_HTXML_ELEMENTS_DOCTYPE_HPP

#include <boost/htxml/element.hpp>

using namespace std;

namespace boost {
  namespace htxml {
    namespace elements {

      /*!
      A !DOCTYPE element
      
      A doctype element is a specialized element that represents \<!DOCTYPE\> 
      element in an XHTML document.
      */
      class doctype : public element
      {
      public:
        /*!
        Default constructor
        
        Creates a new doctype element.
        \param parent  Parent element in the DOM tree.
        */
        doctype(ptr_element_t& parent) : element("!DOCTYPE", parent)
        {
        }

        /*!
        Creates a new doctype element.
        */
        doctype() : element("!DOCTYPE")
        {
        }

        /*!
        Checks if a element is a singleton or not
        
        \returns    Always returns True
        */
        virtual bool isSingleton()
        { 
          return true;
        }

        /*!
        Clones a element object
        
        \returns    A cloned copy of this element
        */
        virtual ptr_element_t clone()
        {
          return ptr_element_t(new doctype(*this));
        }

        /*!
        Writes a doctype element
        
        \param  strm    Stream to write to
        */
        virtual void write(std::ostream& strm, bool withTags = true)
        {
          vector<string>  tojoin;
          tojoin.push_back( name() );

          attrib_list_t attr = attributes();
          attrib_list_t::reverse_iterator attribIter = attr.rbegin();
          for( ; attribIter != attr.rend(); ++attribIter )
            tojoin.push_back( (*attribIter)._name );

          if( withTags )
          {
            strm << "<";
            strm << join(tojoin, " ");
            strm << ">";
          }
        }

      protected:
        /*!
        Parses a single attribute string
        
        Most important thing to do is NOT strip the quotes!

        \param attribute Attribute to parse
        */
        virtual void parseAttrib( const string& attribute )
        {
          attrib_value  attrib;
          attrib._name = attribute;
          attrib._singleton = true;
          setAttr(attrib);
        }
      };

    } // namespace elements
  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_ELEMENTS_DOCTYPE_HPP
