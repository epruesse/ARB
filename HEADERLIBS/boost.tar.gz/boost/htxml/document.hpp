//
// document.hpp
// ~~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_DOCUMENT_HPP
#define BOOST_HTXML_DOCUMENT_HPP

#include <boost/functional/hash.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

#include <boost/htxml/dom_tree.hpp>

using namespace std;

namespace boost {
  namespace htxml {

    class dom_tree;

    class document_impl : public element
    {
    private:
      shared_ptr<dom_tree>  _dom_tree;
    
    public:
      document_impl() : element() { }
      
      void  initialize(weak_ptr<element> wparent)
      {
        ptr_element_t parent = wparent.lock();

        setDocument(parent);
        _dom_tree = shared_ptr<dom_tree>(new dom_tree(wparent));
      }
      
      /*!
      Get a list of elements by element name
      
      \param  name  Element name to retrieve
      \returns      List of elements that match the name parameter
      */
      virtual ptr_element_vector_t getElementsByName(const string& name) const
      {
        return _dom_tree->getElementsByName(name);
      }

      /*!
      Get a list of elements by element's ID attribute
      
      \param  id    Id Attribute to retrieve
      \returns      List of elements that match the id parameter
      */
      virtual ptr_element_vector_t getElementsById(const string& id) const
      {
        return _dom_tree->getElementsById(id);
      }

      virtual ptr_element_t factory(string& name, ptr_element_t& parent)
      {
        return _dom_tree->factory(name, parent);
      }
      
    };

    /*!
    The document root of a DOM tree
    
    This is the basic starting point for any parser to read/write a DOM document tree.
    */
    class document : public element
    {
    private:
      shared_ptr<document_impl> _root;
      weak_ptr<element>         _weak_root;
      
      ptr_element_t             _elementBlank;

    public:
      /*!
      Constructs an DOM object
      
      Creates all the default derived element handlers, along with the "root" 
      element of the document tree.
      */
      document() : element()
      {
        _root = shared_ptr<document_impl>(new document_impl);
        _weak_root = _root;
        _document = _root;
        
        _root->initialize(_weak_root.lock());
      }

      /// Destructs ALL the handlers and element tree
      virtual ~document()
      {
      }

      ptr_element_t blankElement()
      {
        return _elementBlank;
      }

      /*!
      Clones a element object
      
      \returns    A cloned copy of this element
      */
      virtual ptr_element_t clone()
      {
        return ptr_element_t(new document(*this));
      }

      virtual ptr_element_t getDocument()
      {
        return _weak_root.lock();
      }
      
      /*!
      Get a list of elements by element name
      
      \param  name  Element name to retrieve
      \returns      List of elements that match the name parameter
      */
      virtual ptr_element_vector_t getElementsByName(const string& name) const
      {
        return _root->getElementsByName(name);
      }

      /*!
      Get a list of elements by element's ID attribute
      
      \param  id    Id Attribute to retrieve
      \returns      List of elements that match the id parameter
      */
      virtual ptr_element_vector_t getElementsById(const string& id) const
      {
        return _root->getElementsById(id);
      }

      virtual ptr_element_t factory(string& name, ptr_element_t& parent)
      {
        return _root->factory(name, parent);
      }

      /*!
      Adds a child element to the element
      
      \param child   Child element to add
      */
      virtual void addChild(const ptr_element_t& child)
      {
        _root->addChild(child);
      }

      /*!
      Finds a child element by name.
      
      \param  name  Name of the child element to get.
      \returns A valid child element, or a element named *blank.
      */
      virtual const ptr_element_t& findChild(const string& name)
      {
        return _root->findChild(name);
      }

      /*!
      Gets the first child of the children list.
      
      \returns    A random-access iterator addressing the first element in the 
                  children list.
      */
      virtual ptr_element_vector_t::iterator  firstChild()
      {
        return _root->firstChild();
      }

      /*!
      Gets the last child of the children list.
      
      \returns    A random-access iterator addressing the last element in the 
                  children list.
      */
      virtual ptr_element_vector_t::iterator  lastChild()
      {
        return _root->lastChild();
      }

      /*!
      Erases children
      
      \param b  First element to erase
      \param e  Last element to erase
      */
      virtual void  erase(ptr_element_vector_t::iterator b, ptr_element_vector_t::iterator e )
      {
        _root->erase(b,e);
      }


      /*!
      Reads a element and it's children
      
      \param strm    istream to read the input from
      */
      virtual void read(istream& strm)
      {
        _root->read(strm);
      }

      virtual void write(ostream& strm, bool withTags = true)
      {
        _root->write(strm, withTags);
      }

    };

  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_DOCUMENT_HPP
