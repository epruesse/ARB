//
// singleton.hpp
// ~~~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_ELEMENTS_SINGLETON_HPP
#define BOOST_HTXML_ELEMENTS_SINGLETON_HPP

#include <boost/htxml/element.hpp>

#include <string>

using namespace std;

namespace boost {
  namespace htxml {
    namespace elements {

      /*!
      A simple XHTML element
      
      A singleton element is a specialized element that represents \<tag /\> 
      element in an XHTML document.
      */
      class singleton : public element
      {
      public:
        /*!
        Default constructor
        
        Creates a new singleton element.

        \param name   Name of the element. For instance 'img' for an \<img /\> 
                      element
        \param parent Parent element in the DOM tree.
        */
        singleton(const string& name)
        : element(name.c_str())
        {
        }

        /*!
        Default constructor
        
        Creates a new singleton element.

        \param name   Name of the element. For instance 'img' for an \<img /\> 
                      element
        \param parent Parent element in the DOM tree.
        */
        singleton(const char* name)
        : element(name)
        {
        }
      
        /*!
        Default constructor
        
        Creates a new singleton element.

        \param name   Name of the element. For instance 'img' for an \<img /\> 
                      element
        \param parent Parent element in the DOM tree.
        */
        singleton(const string& name, ptr_element_t& parent)
        : element(name, parent)
        {
        }

        /*!
        Default constructor
        
        Creates a new singleton element.

        \param name   Name of the element. For instance 'img' for an \<img /\> 
                      element
        \param parent Parent element in the DOM tree.
        */
        singleton(const char* name, ptr_element_t& parent)
        : element(name, parent)
        {
        }
        
        /*!
        Checks if a element is a singleton or not
        
        \returns    Always returns True
        */
        virtual bool  isSingleton()  { return true; }

        /*!
        Clones a element object
        
        \returns    A cloned copy of this element
        */
        virtual ptr_element_t clone()
        {
          return ptr_element_t(new singleton(*this));
        }

        /*!
        Reads the attributes of a element
        
        Reads the attributes for a element until we reach the '>' marker.
        
        \param strm  Stream to read attributes from
        */
        virtual void readAttribs(istream& strm)
        {
          ostringstream  sstrm;
          while( !strm.eof() )
          {
            char ch;
            strm.get(ch);
            if( ch == '>' || (ch == '/' && strm.peek() == '>') )
            {
              // hanging '>' out there
              if( ch == '/' )
                strm.get();
              break;
            }
            else
              sstrm << ch;
          }

          parseAttribs(sstrm.str());
        }

        /*!
        Writes a singleton element
        
        \param  strm    Stream to write to
        */
        virtual void write(std::ostream& strm, bool withTags = true)
        {
          if( withTags )
          {
            strm << "<" ;
            createElement(strm);
            strm << " />";
          }
        }
      };

    } // namespace elements
  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_ELEMENTS_SINGLETON_HPP
