//
// script.hpp
// ~~~~~~~~~~~
//
// Copyright (c) 1998-2009 Andreas Haberstroh (andreas at ibusy dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef BOOST_HTXML_ELEMENTS_SCRIPT_HPP
#define BOOST_HTXML_ELEMENTS_SCRIPT_HPP

#include <boost/htxml/element.hpp>

using namespace std;

namespace boost {
  namespace htxml {
    namespace elements {

      /*!
      A XHTML Comment element
      
      A comment element is a specialized element that represents comment 
      (\<!-- --\>) in an XHTML document.
      */
      class script : public element
      {
      private:
        string _script;  //!<  script string

      public:
        /*!
        Default constructor

        Creates a new comment element.
        \param parent  Parent element in the DOM tree.
        */
        script(ptr_element_t& parent) : element("script", parent)
        {
        }

        /*!
        Checks if a element is a singleton or not

        \returns    Always returns True
        */
        virtual bool isSingleton() { return false; }

        /*!
        Clones a element object
        
        \returns    A cloned copy of this element
        */
        virtual ptr_element_t clone()
        {
          return ptr_element_t(new script(*this));
        }

        /*!
        Reads a comment element
        
        \param strm    istream to read the input from
        */
        virtual void read(std::istream& strm)
        {
          string  value;
          char ch;
          while( !strm.eof() )
          {
            strm.get(ch);
            if( ch == '<' )
            {
              // Take a peek for the next char
              char pch = strm.peek();
              if( pch == '/' ) 
              {
                string  testTag = readElement(strm);
                if( testTag == "/script" )
                {
                  strm.get(ch);
                  break;
                }
                else
                {
                  value += testTag;
                  continue ;
                }
              }
            }

            value += ch;
          }
          
          setValue(value);
        }
      };

    } // namespace elements
  } // namespace htxml
} // namespace boost

#endif // BOOST_HTXML_ELEMENTS_SCRIPT_HPP
